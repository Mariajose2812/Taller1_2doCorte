/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes;

/**
 *
 * @author Maria jose
 */
import java.util.Arrays;
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        Scanner sc = new Scanner(System.in);

        // Leer tamaño del primer vector
        System.out.print("Escriba el tamaño del primer vector: ");
        int n1 = sc.nextInt();
        double[] vector1 = new double[n1];

        // Leer elementos del primer vector
        System.out.println("Escriba los elementos del primer vector:");
        for (int i = 0; i < n1; i++) {
            vector1[i] = sc.nextDouble();
        }

        // Leer tamaño del segundo vector
        System.out.print("Escriba el tamaño del segundo vector: ");
        int n2 = sc.nextInt();
        double[] vector2 = new double[n2];

        // Leer elementos del segundo vector
        System.out.println("escriba los  elementos del segundo vector:");
        for (int i = 0; i < n2; i++) {
            vector2[i] = sc.nextDouble();
        }

        // Fusionar vectores y ordenar de manera ascendente
        double[] vectorAsc = new double[n1 + n2];
        System.arraycopy(vector1, 0, vectorAsc, 0, n1);
        System.arraycopy(vector2, 0, vectorAsc, n1, n2);
        Arrays.sort(vectorAsc);

        // Fusionar vectores y ordenar de manera descendente
        double[] vectorDesc = new double[n1 + n2];
        System.arraycopy(vector1, 0, vectorDesc, 0, n1);
        System.arraycopy(vector2, 0, vectorDesc, n1, n2);
        Arrays.sort(vectorDesc);
        for (int i = 0; i < vectorDesc.length / 2; i++) {
            double temp = vectorDesc[i];
            vectorDesc[i] = vectorDesc[vectorDesc.length - i - 1];
            vectorDesc[vectorDesc.length - i - 1] = temp;
        }

        // Mostrar resultados
        System.out.println("Vector fusionado y ordenado de manera ascendente:");
        for (int i = 0; i < vectorAsc.length; i++) {
            System.out.print(vectorAsc[i] + " ");
        }
        System.out.println();

        System.out.println("Vector fusionado y ordenado de manera descendente:");
        for (int i = 0; i < vectorDesc.length; i++) {
            System.out.print(vectorDesc[i] + " ");
        }
        System.out.println();
    }
}
    
    

