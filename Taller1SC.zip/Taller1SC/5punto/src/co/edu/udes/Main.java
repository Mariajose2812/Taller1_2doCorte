/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    
        Scanner teclado = new Scanner(System.in);

        System.out.print("Numero de asteriscos de la base y altura del triangulo: ");
        int n = teclado.nextInt();

        System.out.print("Escriba la alineación del triángulo (D para derecha o I para izquierda): ");
        char alineacion = teclado.next().charAt(0);

        if (alineacion == 'D') {
            
            // Triángulo alineado a la derecha
            for (int i = 0; i < n; i++) {
                for (int j = 0; j <= i; j++) {
                    System.out.print("*");
                }
                System.out.println();
            }
        } else if (alineacion == 'I') {
            
            
            // Triángulo alineado a la izquierda
            for (int i = n; i >= 1; i--) {
                for (int j = 1; j <= i; j++) {
                    System.out.print("*");
                }
                System.out.println();
            }
        } else {
            System.out.println("La alineación ingresada no es válida.");
        }
    }
}
    
    

