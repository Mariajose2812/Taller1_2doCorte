/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes;

/**
 *
 * @author Maria jose
 */
public class atributo8 {

    /**
     * @param args the command line arguments
     */
    public class Asignatura {
    private String nombre;
    private int creditos;
    private String carrera;
}
    }
    
