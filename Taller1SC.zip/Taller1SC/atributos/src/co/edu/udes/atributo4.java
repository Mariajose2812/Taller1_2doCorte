/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes;

/**
 *
 * @author Maria jose
 */
public class atributo4 {

    /**
     * @param args the command line arguments
     */
   public class Edificio {
    private String nombre;
    private String direccion;
    private int numPisos;
}

    }
    

