/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes;

/**
 *
 * @author Maria jose
 */
public class atributo6 {

    /**
     * @param args the command line arguments
     */
    public class Ciudad {
    private String nombre;
    private int poblacion;
    private String pais;
}

        // TODO code application logic here
    }
    

