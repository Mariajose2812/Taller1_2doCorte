/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes;

/**
 *
 * @author Maria jose
 */
public class atributo3 {

    /**
     * @param args the command line arguments
     */
    public class Persona {
    private String nombre;
    private int edad;
    private String genero;
}
    
}
