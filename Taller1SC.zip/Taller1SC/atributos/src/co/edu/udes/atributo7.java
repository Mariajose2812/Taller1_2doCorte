/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes;

/**
 *
 * @author Maria jose
 */
public class atributo7 {

    /**
     * @param args the command line arguments
     */
   public class Pais {
    private String nombre;
    private String continente;
    private String capital;
}
    }
    

