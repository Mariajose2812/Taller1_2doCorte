/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
    Scanner teclado = new Scanner(System.in);
    
    System.out.print("Ingrese la fecha (dia/mes/año): ");
    String fechaStr = teclado.nextLine();
    
    String[] fechaArr = fechaStr.split("/");
    int dia = Integer.parseInt(fechaArr[0]);
    int mes = Integer.parseInt(fechaArr[1]);
    int año = Integer.parseInt(fechaArr[2]);
    boolean esFechaValida = true;
    int diasTranscurridos = 0;
    if (año < 1) {
      esFechaValida = false;
    }
    else {
        
      switch (mes) {
        case 1: case 3: case 5: case 7: case 8: case 10: case 12:
          if (dia < 1 || dia > 31) {
            esFechaValida = false;
          }
          else {
            diasTranscurridos += dia;
          }
          break;
        case 4: case 6: case 9: case 11:
          if (dia < 1 || dia > 30) {
            esFechaValida = false;
          }
          else {
            diasTranscurridos += dia + 31;
          }
          break;
        case 2:
          if ((año % 4 == 0 && año % 100 != 0) || año % 400 == 0) {
            if (dia < 1 || dia > 29) {
              esFechaValida = false;
            }
            else {
              diasTranscurridos += dia + 31 + 29;
            }
          }
          else {
            if (dia < 1 || dia > 28) {
              esFechaValida = false;
            }
            else {
              diasTranscurridos += dia + 31 + 28;
            }
          }
          break;
        default:
          esFechaValida = false;
          break;
      }
    }
    if (esFechaValida) {
      System.out.println("La fecha ingresada es válida y han transcurrido " + diasTranscurridos + " días del año.");
    }
    else {
      System.out.println("La fecha ingresada no es válida.");
    }
  }
}
    
   
