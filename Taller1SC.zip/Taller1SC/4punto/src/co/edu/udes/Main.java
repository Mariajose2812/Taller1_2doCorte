/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.print( "Numero de elementos de la serie de Fibonacci a calcular: ");
        int numElementos = sc.nextInt();

        int num1 = 0, num2 = 1, fib;
        System.out.print(num1 + " " + num2 + " ");

        for (int i = 2; i < numElementos; i++) {
            fib = num1 + num2;
            System.out.print(fib + " ");
            num1 = num2;
            num2 = fib;
        }
    }
}
    
    

