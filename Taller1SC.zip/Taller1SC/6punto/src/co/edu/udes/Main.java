/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);

        System.out.print("Escriba una frase: ");
        String frase = teclado.nextLine();
        
        // separa la frase en palabras
        String[] palabras = frase.split("\\s+"); 

        System.out.println("Numero de palabras: " + palabras.length);
        for (int i = 0; i < palabras.length; i++) {
            System.out.println("Palabra " + (i + 1) + ": " + palabras[i] + " (caracteres: " + palabras[i].length() + ")");
        }
    }
}





