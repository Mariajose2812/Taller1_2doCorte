/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes;

/**
 *
 * @author Maria jose
 */
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Numero de asignaturas: ");
        int numAsignaturas = teclado.nextInt();

        // Creamos el mapa para guardar las horas de estudio mensuales por asignatura
        Map<String, int[]> horasEstudio = new HashMap<>();

        // Pedimos las horas de estudio mensuales por asignatura al usuario
        for (int i = 1; i <= numAsignaturas; i++) {
            System.out.print("Nombre de la asignatura " + i + ": ");
            String nombreAsignatura = teclado.next();

            int[] horasMensuales = new int[12];
            for (int j = 0; j < 12; j++) {
                System.out.print("Horas de estudio mensuales de " + nombreAsignatura + " para el mes " + (j + 1) + ": ");
                horasMensuales[j] = teclado.nextInt();
            }

            horasEstudio.put(nombreAsignatura, horasMensuales);
        }

        // Calculamos el total anual de horas dedicadas a cada asignatura
        Map<String, Integer> totalHorasAnuales = new HashMap<>();
        for (String asignatura : horasEstudio.keySet()) {
            int[] horasMensuales = horasEstudio.get(asignatura);
            int totalHorasAnual = 0;
            for (int horas : horasMensuales) {
                totalHorasAnual += horas;
            }
            totalHorasAnuales.put(asignatura, totalHorasAnual);
        }

        // Calculamos el total mensual de horas dedicadas a estudiar
        int[] totalHorasMensuales = new int[12];
        for (String asignatura : horasEstudio.keySet()) {
            int[] horasMensuales = horasEstudio.get(asignatura);
            for (int i = 0; i < 12; i++) {
                totalHorasMensuales[i] += horasMensuales[i];
            }
        }

        // Buscamos la asignatura más estudiada
        String asignaturaMasEstudiada = "";
        int totalHorasMasEstudiada = 0;
        for (String asignatura : totalHorasAnuales.keySet()) {
            int totalHoras = totalHorasAnuales.get(asignatura);
            if (totalHoras > totalHorasMasEstudiada) {
                asignaturaMasEstudiada = asignatura;
                totalHorasMasEstudiada = totalHoras;
            }
        }

        // Buscamos la asignatura menos estudiada
        String asignaturaMenosEstudiada = "";
        int totalHorasMenosEstudiada = Integer.MAX_VALUE;
        for (String asignatura : totalHorasAnuales.keySet()) {
            int totalHoras = totalHorasAnuales.get(asignatura);
            if (totalHoras < totalHorasMenosEstudiada) {
                asignaturaMenosEstudiada = asignatura; 
                
                        
    }
    
}
    }
}
