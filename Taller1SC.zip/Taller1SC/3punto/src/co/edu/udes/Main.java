/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    Scanner teclado = new Scanner(System.in);
    
    System.out.print("Escribe el numero de latas a apilar: ");
      
    int numeroLatas = teclado.nextInt();

        int i = 1;
        int totalLatas = 0;
        while (totalLatas < numeroLatas) {
            totalLatas += i;
            i++;
        }

        if (totalLatas == numeroLatas) {
            System.out.println("El numero de latas es adecuado para apilar en forma triangular.");
        } else {
            System.out.println("El numero de latas no es adecuado para apilar en forma triangular.");
            System.out.println("El numero mas cercano de latas que se puede apilar es: " + (totalLatas - i + 1));
        }
    }
}

    

