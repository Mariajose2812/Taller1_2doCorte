/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
    Scanner teclado = new Scanner(System.in);
        
    System.out.print("Escriba los segundos: ");
    
    int tiempoSeg = teclado.nextInt();
    int dias = tiempoSeg / 86400;
    int horas = (tiempoSeg % 86400) / 3600;
    int minutos = ((tiempoSeg % 86400) % 3600) / 60;
    int segundos = ((tiempoSeg % 86400) % 3600) % 60;
    
    System.out.println("Formato 24H: " + dias + " dias, " + horas + " horas, " + minutos + " minutos y " + segundos + " segundos.");
    int horas12 = horas;
    String ampm = "Am";
    if (horas12 >= 12) {
      horas12 -= 12;
      ampm = "Pm";
    }
    if (horas12 == 0) {
      horas12 = 12;
    }
    System.out.println("Formato 12H: " + dias + " dias, " + horas12 + " horas, " + minutos + " minutos y " + segundos + " segundos " + ampm + ".");
  }
}
    
    

